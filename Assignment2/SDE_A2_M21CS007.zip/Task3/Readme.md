# Face and Logo detection
## 1. Run the first cell of .ipynb file, after installing the updated version of libraries Restart Runtime and then again run the complete file.
## 2. It will ask for uploading the JSON file that contain the key for Accessing Cloud Vision API. Use the JSON file provided for same.
## 3. The images are stored at https://jay0774.github.io/IMAGES/
## 4. Output of images are in Report.
